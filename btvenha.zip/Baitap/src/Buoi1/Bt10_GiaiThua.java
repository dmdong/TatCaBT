package Buoi1;

public class Bt10_GiaiThua {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
